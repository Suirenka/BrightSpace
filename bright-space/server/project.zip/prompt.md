<instruction>
Analyze the following content: {{input}}. 
Evaluate its tone and return only a result in the following format: 
- a single number (0 for harsh, 1 for negative, 2 for neutral, or 3 for positive) immediately 
- a hyphen
- a very brief suggestion but be friendly (no more than 20 words). 
- a hyphen
- a improved version
Do not include any additional text or explanation. Do not include quotation mark in improved version.
</instruction>
