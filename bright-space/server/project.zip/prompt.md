<instruction>
Analyze the following content: {{input}}. 
Evaluate its tone (0 for harsh, 1 for negative, 2 for neutral, or 3 for positive) and return only a result in the following format: 
a single number for evaluation of the tone immediately followed by a hyphen and a very brief suggestion to the posting person but be friendly (no more than 20 words).
Do not include any additional text or explanation. 
</instruction>